﻿// Modified by Godra
// 17-Aug-20
// Added/Changed public constants (LREAL, BOOL, BOOLARRAY, made up 16-byte (128-bit) types, unsigned for all supported types, strings)

namespace LibplctagWrapper
{
    public static class DataType
    {
        /* 1-byte / 8-bit types */
        public const int Int8 = 1;
        public const int SINT = 1;
        public const int UInt8 = 1;
        public const int USINT = 1;
        public const int BOOL = 1;

        /* 2-byte / 16-bit types */
        public const int Int16 = 2;
        public const int INT = 2;
        public const int UInt16 = 2;
        public const int UINT = 2;

        /* 4-byte / 32-bit types */
        public const int Int32 = 4;
        public const int DINT = 4;
        public const int UInt32 = 4;
        public const int UDINT = 4;
        public const int Float32 = 4;
        public const int REAL = 4;
        public const int BOOLARRAY = 4;

        /* 8-byte / 64-bit types */
        public const int Int64 = 8;
        public const int LINT = 8;
        public const int UInt64 = 8;
        public const int ULINT = 8;
        public const int Float64 = 8;
        public const int LREAL = 8;

        /* 16-byte / 128-bit types */
        public const int Int128 = 16;
        public const int QDINT = 16;
        public const int UInt128 = 16;
        public const int QUDINT = 16;
        public const int Float128 = 16;
        public const int QREAL = 16;

        /* String types */
        public const int StringMicro800 = 256;
        public const int StringControlLogix = 88;
        public const int StringPLC5SLCMLGX = 84;
        public const int ShortString = 256;
    }
}
