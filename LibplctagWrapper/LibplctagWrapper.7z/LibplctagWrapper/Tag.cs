﻿// Modified by Godra
// 22-Nov-19
// Added string.Format to StringBuilder
// Changed all public properties from { get; } to { get; set; }
// 03-Aug-20
// Added class to read Controller and/or Program tags from ControlLogix CPU
// 10-Aug-20
// Updated all entries relevant to new cpu definitions
// 05-Nov-20
// Added Modbus related entries

using System;
using System.Text;

namespace LibplctagWrapper
{
    //"protocol=ab_eip&gateway=192.168.0.100&cpu=SLC&elem_size=4&elem_count=1&name=F8:0&debug=1"
    //"protocol=modbus_tcp&gateway=192.168.0.100&cpu=MODBUS&elem_size=2&elem_count=2&name=hr1&int32_byte_order=3210&debug=1"
    public class Tag
    {
        public string Protocol { get; set; }

        public string IpAddress { get; set; }

        public CpuType Cpu { get; set; }

        public string Name { get; set; }

        public int ElementSize { get; set; }

        public int ElementCount { get; set; }

        public string UniqueKey { get; set; }

        /// <summary>
        /// Creates a tag for PLC5 / SLC / MicroLogix processor types (the path is not specified)
        /// </summary>
        /// <param name="ipAddress">IP address of the gateway for this protocol. Could be the IP address of the PLC you want to access.</param>
        /// <param name="cpuType">AB CPU models</param>
        /// <param name="name">The textual name of the tag to access. The name is anything allowed by the protocol. E.g. myDataStruct.rotationTimer.ACC, myDINTArray[42] etc.</param>
        /// <param name="elementSize">The size of an element in bytes. The tag is assumed to be composed of elements of the same size. For structure tags, use the total size of the structure.</param>
        /// <param name="elementCount">elements count: 1- single, n-array.</param>
        /// <param name="byteOrder">Applicable to Modbus registers and defines byte order for the data type (16/32/64 bit)</param>
        /// <param name="debugLevel"></param>
        public Tag(string protocol, string ipAddress, CpuType cpuType, string name, int elementSize, int elementCount, string byteOrder = null, int debugLevel = 0)
            : this(protocol, ipAddress, string.Empty, cpuType, name, elementSize, elementCount, byteOrder, debugLevel)
        {

        }

        /// <summary>
        /// Creates a tag. If the CPU type is ControlLogix/Logixpccc/njnx/Modbus, the path has to be specified.
        /// </summary>
        /// <param name="ipAddress">IP address of the gateway for this protocol. Could be the IP address of the PLC you want to access.</param>
        /// <param name="path">Required for ControlLogix/Logixpccc/njnx/Modbus, Optional for PLC/SLC/MLGX. It represents UnitID for Modbus.
        /// <para></para>Communication Port Type: 1- Backplane, 2- Control Net/Ethernet, DH+ Channel A, DH+ Channel B, 3- Serial
        /// <para></para> Slot number where cpu is installed: 0,1.. </param>
        /// <param name="slot"></param>
        /// <param name="cpuType">AB CPU models</param>
        /// <param name="name">The textual name of the tag to access. The name is anything allowed by the protocol. E.g. myDataStruct.rotationTimer.ACC, myDINTArray[42] etc.</param>
        /// <param name="elementSize">The size of an element in bytes. The tag is assumed to be composed of elements of the same size. For structure tags, use the total size of the structure.</param>
        /// <param name="elementCount">elements count: 1- single, n-array.</param>
        /// <param name="byteOrder">Applicable to Modbus registers and defines byte order for the data type (16/32/64 bit)</param>
        /// <param name="debugLevel"></param>
        public Tag(string protocol, string ipAddress, string path, CpuType cpuType, string name, int elementSize, int elementCount, string byteOrder = null, int debugLevel = 0)
        {
            if ((cpuType == CpuType.ControlLogix || cpuType == CpuType.Logixpccc || cpuType == CpuType.NJNX || cpuType == CpuType.MODBUS) && string.IsNullOrEmpty(path))
            {
                if (cpuType == CpuType.MODBUS)
                    throw new ArgumentException("UnitID must be specified");
                else
                    throw new ArgumentException("Path must be specified");
            }

            Protocol = protocol;
            IpAddress = ipAddress;
            Cpu = cpuType;
            Name = name;
            ElementSize = elementSize;
            ElementCount = elementCount;

            var sb = new StringBuilder();

            sb.Append(string.Format("protocol={0}&gateway={1}", protocol, ipAddress));

            if (!string.IsNullOrEmpty(path))
                sb.Append(string.Format("&path={0}", path.Replace(" ", "")));

            sb.Append(string.Format("&cpu={0}&elem_size={1}&elem_count={2}&name={3}", cpuType.ToString().ToUpper(), elementSize, elementCount, name));

            if (byteOrder != null)
                sb.Append(string.Format("&{0}", byteOrder));

            if (debugLevel > 0)
                sb.Append(string.Format("&debug={0}", debugLevel));

            UniqueKey = sb.ToString();
        }

        /// <summary>
        /// Used to read Controller and/or Program tags from ControlLogix CPU. The port type and slot has to be specified.
        /// </summary>
        /// <param name="ipAddress">IP address of the gateway for this protocol. Could be the IP address of the PLC you want to access.</param>
        /// <param name="path">Required for LGX.
        /// <para></para>Communication Port Type: 1- Backplane, 2- Control Net/Ethernet, DH+ Channel A, DH+ Channel B, 3- Serial
        /// <para></para> Slot number where cpu is installed: 0,1.. </param>
        /// <param name="cpuType">AB CPU models</param>
        /// <param name="name">The textual name of the tag to access. The name is "@tags" for Controller tags and "Program:MainProgram.@tags" for Program tags.</param>
        public Tag(string protocol, string ipAddress, string path, CpuType cpuType, string name, int debugLevel = 0)
        {
            if (cpuType == CpuType.ControlLogix && string.IsNullOrEmpty(path))
                throw new ArgumentException("Path must be specified");

            Protocol = protocol;
            IpAddress = ipAddress;
            Cpu = cpuType;
            Name = name;

            var sb = new StringBuilder();

            sb.Append(string.Format("protocol={0}&gateway={1}", protocol, ipAddress));

            if (!string.IsNullOrEmpty(path))
                sb.Append(string.Format("&path={0}", path.Replace(" ", "")));

            sb.Append(string.Format("&cpu={0}&name={1}", cpuType.ToString().ToUpper(), name));

            if (debugLevel > 0)
                sb.Append(string.Format("&debug={0}", debugLevel));

            UniqueKey = sb.ToString();
        }
    }
}
