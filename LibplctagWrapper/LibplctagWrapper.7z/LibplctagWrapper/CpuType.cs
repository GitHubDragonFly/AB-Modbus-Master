﻿// Modified by Godra
// 10-Aug-20
// Updated enum from {LGX, SLC, PLC5} to {ControlLogix, Logixpccc, Micro800, MicroLogix, Slc500, Plc5, NJNX, MODBUS}

namespace LibplctagWrapper
{
    public enum CpuType
    {
        ControlLogix,
        Logixpccc,
        Micro800,
        MicroLogix,
        Slc500,
        Plc5,
        NJNX,
        MODBUS
    }
}
